<<
CREATE TABLE IF NOT EXISTS "{{schemaName}}"."userstest1" (
    "userid" integer NOT NULL,
    "fullname" varchar(100),
    "email" varchar(100)
)
>>

<<
CREATE OR REPLACE FUNCTION "{{schemaName}}".fn_pegv2_updapp_usegroups()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare
v_newusers varchar(4000);
v_delusers varchar(4000);
v_retainedusers varchar(4000);
begin

with a as(select regexp_split_to_table(new.oldugrpusername,',') usr),b as (select regexp_split_to_table(new.ugrpusername,',') usr)
select string_agg(a.usr,',') into v_delusers from a left join b on a.usr = b.usr
where b.usr is null;

with a as(select regexp_split_to_table(new.oldugrpusername,',') usr),b as (select regexp_split_to_table(new.ugrpusername,',') usr)
select string_agg(b.usr,',') into v_newusers from a right join b on a.usr = b.usr
where a.usr is null;


with a as(select regexp_split_to_table(new.oldugrpusername,',') usr),b as (select regexp_split_to_table(new.ugrpusername,',') usr)
select string_agg(b.usr,',') into v_retainedusers from a join b on a.usr = b.usr;


update axactivetasks a set removeflg='T' where assigntoflg='2' and delegation='F' and pownerflg='F' and removeflg='F' and grouped='T'
and assigntoactor= new.ug_actorname 
and actor_user_groups  = new.usergroupname
and touser in(select regexp_split_to_table(v_delusers,','))
and not exists (SELECT b.taskid FROM axactivetaskstatus b WHERE a.taskid = b.taskid);


insert into axactivetasks(eventdatetime,taskid,processname,tasktype,taskname,taskdescription,assigntorole,transid,keyfield,execonapprove,
	keyvalue,transdata,fromrole,fromuser,touser,priorindex,priortaskname,corpdimension,orgdimension,department,grade,datavalue,
	displayicon,displaytitle,displaysubtitle,displaycontent,displaybuttons,groupfield,groupvalue,priorusername,initiator,mapfieldvalue,
	useridentificationfilter,useridentificationfilter_of,mapfield_group,mapfield,grouped,indexno,subindexno,processowner,assigntoflg,
	assigntoactor,actorfilter,recordid,processownerflg,pownerfilter,approvereasons,defapptext,returnreasons,defrettext,rejectreasons,defregtext,
	approvalcomments,rejectcomments,returncomments,escalation,reminder,displaymcontent,groupwithpriorindex,returnable,allowsend,
	allowsendflg,sendtoactor,initiator_approval,usebusinessdatelogic,initonbehalf,changedusr,actor_user_groups) 	
	select distinct eventdatetime,taskid,processname,tasktype,taskname,taskdescription,assigntorole,transid,keyfield,
	execonapprove,keyvalue,transdata,fromrole,fromuser,regexp_split_to_table(v_newusers,','),priorindex,priortaskname,corpdimension,
	orgdimension,department,grade,datavalue,displayicon,displaytitle,displaysubtitle,displaycontent,
	displaybuttons,groupfield,groupvalue,priorusername,initiator,mapfieldvalue,	useridentificationfilter,
	useridentificationfilter_of,mapfield_group,mapfield,'T',indexno,subindexno,
	processowner,assigntoflg,assigntoactor,actorfilter,recordid,processownerflg,pownerfilter,
	approvereasons,defapptext,returnreasons,defrettext,rejectreasons,defregtext,
	approvalcomments,rejectcomments,returncomments,escalation,reminder,displaymcontent,groupwithpriorindex,returnable,
	allowsend,allowsendflg,sendtoactor,initiator_approval,usebusinessdatelogic,initonbehalf,'T',new.usergroupname
	from axactivetasks a 	
	 where assigntoflg='2' and delegation='F' and pownerflg ='F' and removeflg ='F' and grouped='T'
	 and assigntoactor = new.ug_actorname
	 and actor_user_groups  = new.usergroupname 
	 and not exists (SELECT b.taskid FROM axactivetaskstatus b WHERE a.taskid = b.taskid); 

	
return new;
end; 
$function$
>>

<<
INSERT INTO axpages (name,caption,props,blobno,img,visible,type,parent,ordno,levelno,updatedon,createdon,importedon,createdby,updatedby,importedby,readonly,updusername,category,pagetype,intview,webenable,shortcut,icon,websubtype,workflow,oldappurl) VALUES ('HP1778565934880','Axpert Inbox','htmlPages.aspx?load=1778565934880',1,NULL,'T','p',NULL,(SELECT COALESCE(MAX(ordno),0) + 1 FROM axpages),0,'12/05/2026 11:36:29 AM','12/05/2026 11:36:29 AM',NULL,'admin','admin',NULL,NULL,NULL,NULL,'web',NULL,NULL,NULL,NULL,'htmlpage',NULL,NULL)
>>