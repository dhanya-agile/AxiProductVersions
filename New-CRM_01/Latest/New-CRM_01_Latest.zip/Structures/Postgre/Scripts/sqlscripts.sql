<<
CREATE TABLE IF NOT EXISTS "{{schemaName}}"."mdmt21" (
    "mdmt21id" numeric(16,0) NOT NULL,
    "cancel" varchar(1),
    "sourceid" numeric(16,0),
    "mapname" varchar(20),
    "username" varchar(50),
    "modifiedon" timestamp without time zone,
    "createdby" varchar(50),
    "createdon" timestamp without time zone,
    "wkid" varchar(15),
    "app_level" numeric(3,0),
    "app_desc" numeric(1,0),
    "app_slevel" numeric(3,0),
    "cancelremarks" varchar(150),
    "wfroles" varchar(250),
    "dob2" date,
    "dtob2" timestamp without time zone
)
>>

<<
CREATE OR REPLACE FUNCTION "{{schemaName}}".fn_ax_widget_published()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
declare 
v_sid numeric(15);

	BEGIN
		select nextval('ax_widget_publish_seq') into v_sid ; 

        IF (TG_OP = 'INSERT') THEN 
		
		NEW.WIDGET_ID = v_sid;
		
		return new;
	end if;
end; 
$function$
>>

<<
CREATE OR REPLACE FUNCTION "{{schemaName}}".axp_sch_axgs000001()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
begin 
if tg_op='INSERT'  then 

insert  into axp_appsearch_data_v2 (hltype,structname,searchtext,params,docid) values('tstruct','Taskm',new.taskid,'~taskid='||new.taskid,'AXGS000001');

else if  tg_op='UPDATE'   then

insert  into axp_appsearch_data_v2 (hltype,structname,searchtext,params,docid) values('tstruct','Taskm',new.taskid,'~taskid='||new.taskid,'AXGS000001');

else  delete  FROM axp_appsearch_data_v2 where hltype='tstruct' and params='~taskid='||old.taskid;

 end if;

 end if;
return new;
exception

      when unique_violation then

UPDATE axp_appsearch_data_v2
        SET searchtext = NEW.taskid, params = '~taskid=' || NEW.taskid
        WHERE hltype = 'tstruct' AND docid = 'AXGS000001';

        RETURN NEW;
   when others then 

return new;

 end ;  
 $function$
>>

<<
CREATE TRIGGER axp_sch_axgs000001 AFTER INSERT OR UPDATE ON empfo1 FOR EACH ROW EXECUTE FUNCTION axp_sch_axgs000001()
>>

<<
CREATE TRIGGER axp_sch_axgs000001 AFTER INSERT OR UPDATE ON taskf_hdr FOR EACH ROW EXECUTE FUNCTION axp_sch_axgs000001()
>>

<<
CREATE OR REPLACE FUNCTION "{{schemaName}}".axp_sch_axgs000001()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
begin 
if tg_op='INSERT'  then 

insert  into axp_appsearch_data_v2 (hltype,structname,searchtext,params,docid) values('tstruct','Taskm',new.taskid,'~taskid='||new.taskid,'AXGS000001');

else if  tg_op='UPDATE'   then

insert  into axp_appsearch_data_v2 (hltype,structname,searchtext,params,docid) values('tstruct','Taskm',new.taskid,'~taskid='||new.taskid,'AXGS000001');

else  delete  FROM axp_appsearch_data_v2 where hltype='tstruct' and params='~taskid='||old.taskid;

 end if;

 end if;
return new;
exception

      when unique_violation then

UPDATE axp_appsearch_data_v2
        SET searchtext = NEW.taskid, params = '~taskid=' || NEW.taskid
        WHERE hltype = 'tstruct' AND docid = 'AXGS000001';

        RETURN NEW;
   when others then 

return new;

 end ;  
 $function$
>>

<<
CREATE TRIGGER axp_sch_axgs000001 AFTER INSERT OR UPDATE ON empfo1 FOR EACH ROW EXECUTE FUNCTION axp_sch_axgs000001()
>>

<<
CREATE TRIGGER axp_sch_axgs000001 AFTER INSERT OR UPDATE ON taskf_hdr FOR EACH ROW EXECUTE FUNCTION axp_sch_axgs000001()
>>

<<
INSERT INTO axpages (name,caption,props,blobno,img,visible,type,parent,ordno,levelno,updatedon,createdon,importedon,createdby,updatedby,importedby,readonly,updusername,category,pagetype,intview,webenable,shortcut,icon,websubtype,workflow,oldappurl) VALUES ('HP1778565934880','Axpert Inbox','htmlPages.aspx?load=1778565934880',1,NULL,'T','p',NULL,(SELECT COALESCE(MAX(ordno),0) + 1 FROM axpages),0,'12/05/2026 11:36:29 AM','12/05/2026 11:36:29 AM',NULL,'admin','admin',NULL,NULL,NULL,NULL,'web',NULL,NULL,NULL,NULL,'htmlpage',NULL,NULL)
>>